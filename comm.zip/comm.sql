-- --------------------------------------------------------
-- 主機:                           192.168.1.45
-- 服務器版本:                        5.5.5-10.0.17-MariaDB - mariadb.org binary distribution
-- 服務器操作系統:                      Win64
-- HeidiSQL 版本:                  8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 導出  表 community.it_sessions 結構
CREATE TABLE IF NOT EXISTS `it_sessions` (
  `session_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在導出表  community.it_sessions 的資料：4 rows
/*!40000 ALTER TABLE `it_sessions` DISABLE KEYS */;
INSERT INTO `it_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
	('2ab764108dcda5ed769110c03508806a', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', 1459417741, 'a:12:{s:9:"user_data";s:0:"";s:7:"user_sn";s:2:"26";s:7:"user_id";s:4:"rick";s:9:"user_name";s:9:"曹宇賢";s:10:"user_email";s:23:"rick.tsao@chupei.com.tw";s:12:"supper_admin";s:1:"1";s:15:"user_login_time";s:19:"2016-03-31 17:53:00";s:9:"user_auth";a:8:{i:0;s:4:"auth";i:1;s:8:"auth-dir";i:2;s:9:"authgroup";i:3;s:8:"bulletin";i:4;s:6:"course";i:5;s:10:"daily_good";i:6;s:5:"media";i:7;s:4:"news";}s:13:"frontend_auth";a:0:{}s:9:"func_auth";a:0:{}s:10:"user_group";a:2:{i:0;s:1:"3";i:1;s:1:"5";}s:7:"comm_id";s:8:"5tgb4rfv";}'),
	('e35d4b7a394b1195576a03765979a500', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', 1459421413, 'a:12:{s:9:"user_data";s:0:"";s:7:"user_sn";s:2:"26";s:7:"user_id";s:4:"rick";s:9:"user_name";s:9:"曹宇賢";s:10:"user_email";s:23:"rick.tsao@chupei.com.tw";s:12:"supper_admin";s:1:"1";s:15:"user_login_time";s:19:"2016-03-31 18:45:17";s:9:"user_auth";a:11:{i:0;s:4:"auth";i:1;s:8:"auth-dir";i:2;s:9:"authgroup";i:3;s:8:"bulletin";i:4;s:6:"course";i:5;s:10:"daily_good";i:6;s:5:"media";i:7;s:9:"msgcenter";i:8;s:13:"msgcenter-dir";i:9;s:4:"news";i:10;s:7:"uni_msg";}s:13:"frontend_auth";a:0:{}s:9:"func_auth";a:0:{}s:10:"user_group";a:2:{i:0;s:1:"3";i:1;s:1:"5";}s:7:"comm_id";s:8:"5tgb4rfv";}'),
	('dc67e6e55d35b29969d453bd4e80f181', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', 1459417660, 'a:2:{s:9:"user_data";s:0:"";s:9:"veri_code";s:6:"ESQAMC";}'),
	('f37fc601953e274e9acf99eee94980c3', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', 1459417709, '');
/*!40000 ALTER TABLE `it_sessions` ENABLE KEYS */;


-- 導出  表 community.mailbox 結構
CREATE TABLE IF NOT EXISTS `mailbox` (
  `sn` int(8) unsigned zerofill NOT NULL,
  `type` int(8) unsigned NOT NULL COMMENT '1:掛號信  2:包裹',
  `booked` datetime NOT NULL COMMENT '登錄時間',
  `booker` datetime NOT NULL COMMENT '登錄人',
  `user_sn` int(8) unsigned NOT NULL COMMENT '收件人',
  `received` datetime NOT NULL COMMENT '領取時間',
  `receiver` varchar(50) NOT NULL COMMENT '領收人',
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='郵件領取';

-- 正在導出表  community.mailbox 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `mailbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `mailbox` ENABLE KEYS */;


-- 導出  表 community.parking 結構
CREATE TABLE IF NOT EXISTS `parking` (
  `sn` int(11) DEFAULT NULL,
  `parking_id` varchar(10) DEFAULT NULL,
  `location_id` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='社區車位';

-- 正在導出表  community.parking 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `parking` DISABLE KEYS */;
/*!40000 ALTER TABLE `parking` ENABLE KEYS */;


-- 導出  表 community.sys_backend_log 結構
CREATE TABLE IF NOT EXISTS `sys_backend_log` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(6) DEFAULT NULL,
  `ip` varchar(50) NOT NULL,
  `module_id` varchar(50) NOT NULL,
  `desc` varchar(500) NOT NULL,
  `action` tinyint(1) DEFAULT '0' COMMENT '0:使用狀況,1:動作',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `active_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_backend_log 的資料：1 rows
/*!40000 ALTER TABLE `sys_backend_log` DISABLE KEYS */;
INSERT INTO `sys_backend_log` (`sn`, `user_id`, `ip`, `module_id`, `desc`, `action`, `start_date`, `end_date`, `active_date`) VALUES
	(2, 'admin', 'fe80::94b7:7d58:efc1:9985', 'auth', '新增人員[bbb]', 0, NULL, NULL, '2015-03-24 18:17:39');
/*!40000 ALTER TABLE `sys_backend_log` ENABLE KEYS */;


-- 導出  表 community.sys_config 結構
CREATE TABLE IF NOT EXISTS `sys_config` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `param1` varchar(100) DEFAULT NULL COMMENT '參數1',
  `param2` varchar(100) DEFAULT NULL COMMENT '參數1',
  `desc` varchar(100) DEFAULT NULL,
  `launch` tinyint(1) DEFAULT '1',
  `updated` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='系統配置設定';

-- 正在導出表  community.sys_config 的資料：~1 rows (大約)
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` (`sn`, `id`, `value`, `param1`, `param2`, `desc`, `launch`, `updated`, `created`) VALUES
	(3, 'comm_id', '5tgb4rfv', NULL, NULL, NULL, 1, NULL, NULL);
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;


-- 導出  表 community.sys_frontend_log_2016 結構
CREATE TABLE IF NOT EXISTS `sys_frontend_log_2016` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(40) DEFAULT NULL,
  `user_id` varchar(6) DEFAULT NULL,
  `ip` varchar(50) NOT NULL,
  `module_id` varchar(50) NOT NULL,
  `desc` varchar(500) NOT NULL,
  `action` tinyint(1) DEFAULT '0' COMMENT '0:模組停留狀況,1:動作',
  `stay_time` smallint(6) DEFAULT '0',
  `active_time` int(11) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_frontend_log_2016 的資料：1 rows
/*!40000 ALTER TABLE `sys_frontend_log_2016` DISABLE KEYS */;
INSERT INTO `sys_frontend_log_2016` (`sn`, `session_id`, `user_id`, `ip`, `module_id`, `desc`, `action`, `stay_time`, `active_time`, `create_date`) VALUES
	(1, 'a5f1e111f8bc2b15da42e7ef50efd8c7', 'rick', '::1', 'login', '後台登入 - 曹宇賢', 1, 0, 1458913780, '2016-03-25 21:49:40');
/*!40000 ALTER TABLE `sys_frontend_log_2016` ENABLE KEYS */;


-- 導出  表 community.sys_function 結構
CREATE TABLE IF NOT EXISTS `sys_function` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `is_frontend` tinyint(1) NOT NULL DEFAULT '1' COMMENT '前端:1,後端:0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_function 的資料：~6 rows (大約)
/*!40000 ALTER TABLE `sys_function` DISABLE KEYS */;
INSERT INTO `sys_function` (`sn`, `id`, `title`, `description`, `is_frontend`, `updated`, `created`) VALUES
	(1, 'land_adv', '土地查詢進階功能', '土地查詢進階功能', 1, '2015-07-30 13:44:20', '2015-07-30 13:44:21'),
	(2, 'a7_sign_adv', 'a7配地可顯示地址', 'a7配地可顯示地址', 1, '2015-07-30 13:44:20', '2015-07-30 13:44:21'),
	(3, 'a7_result_adv', 'a7配地成果下載權限', 'a7配地成果下載權限', 1, '2015-07-30 13:44:20', '2015-07-30 13:44:21'),
	(4, 'develop', '工程模式', '工程模式', 1, '2015-07-30 13:44:20', '2015-07-30 13:44:21'),
	(5, 'lvr_find', '實價登錄勾機資料', '可看實價登錄勾機資料', 1, '2016-02-22 15:01:46', '2016-02-22 15:01:47'),
	(6, 'cases_adv', '委託案源', '委託案源可看尚未揭露之指定開發案源', 1, '2016-02-25 20:58:27', '2016-02-25 20:58:33');
/*!40000 ALTER TABLE `sys_function` ENABLE KEYS */;


-- 導出  表 community.sys_message 結構
CREATE TABLE IF NOT EXISTS `sys_message` (
  `sn` bigint(20) NOT NULL AUTO_INCREMENT,
  `assign_sn` bigint(20) DEFAULT NULL COMMENT '分派sn,若為null則不是由分派而來',
  `from_unit_sn` int(11) NOT NULL COMMENT '單位sn',
  `from_unit_name` varchar(50) NOT NULL COMMENT '單位名稱',
  `from_user_sn` int(11) NOT NULL,
  `to_user_sn` int(11) NOT NULL,
  `category_id` varchar(10) DEFAULT NULL,
  `sub_category_id` varchar(10) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `sub_title` varchar(50) DEFAULT NULL,
  `brief` varchar(500) DEFAULT NULL,
  `msg_content` mediumtext NOT NULL COMMENT '訊息',
  `meeting_date` datetime DEFAULT NULL COMMENT '會議時間',
  `is_read` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已讀取',
  `read_date` datetime DEFAULT NULL COMMENT '讀取時間',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='訊息';

-- 正在導出表  community.sys_message 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `sys_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_message` ENABLE KEYS */;


-- 導出  表 community.sys_message_assign 結構
CREATE TABLE IF NOT EXISTS `sys_message_assign` (
  `sn` bigint(20) NOT NULL AUTO_INCREMENT,
  `from_unit_sn` int(11) NOT NULL COMMENT '單位sn',
  `from_unit_name` varchar(50) NOT NULL COMMENT '單位名稱',
  `from_user_sn` int(11) NOT NULL,
  `to_user_sn` varchar(200) NOT NULL,
  `to_user_id` varchar(1000) NOT NULL,
  `fail_user_id` varchar(1000) DEFAULT NULL,
  `category_id` varchar(10) DEFAULT NULL,
  `sub_category_id` varchar(10) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `sub_title` varchar(50) DEFAULT NULL,
  `brief` varchar(500) DEFAULT NULL,
  `msg_content` mediumtext NOT NULL COMMENT '訊息',
  `meeting_date` datetime DEFAULT NULL COMMENT '會議時間',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='訊息';

-- 正在導出表  community.sys_message_assign 的資料：~5 rows (大約)
/*!40000 ALTER TABLE `sys_message_assign` DISABLE KEYS */;
INSERT INTO `sys_message_assign` (`sn`, `from_unit_sn`, `from_unit_name`, `from_user_sn`, `to_user_sn`, `to_user_id`, `fail_user_id`, `category_id`, `sub_category_id`, `title`, `sub_title`, `brief`, `msg_content`, `meeting_date`, `updated`, `created`) VALUES
	(3, 10, '0', 143, '35,36,37,38,39,42,43,44,141,146,172', 'CH0019-王海翔,CH0026-孫偉欽,CH0034-鄧任勛,CH0039-陳昶瑞,CH0043-蔡名傑,CH0078-林碧玲,CH0080-王金山,CH0084-漆宥辰,CH0090-張明暄,ch0087-楊芝勳,ch0094-沈明仁', NULL, 'notify', NULL, '[廖健宏 ]拜訪行程', NULL, NULL, '[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程', NULL, '2015-09-15 14:16:06', '2015-09-15 14:16:06'),
	(4, 10, '0', 143, '36,37,43', 'CH0026-孫偉欽,CH0034-鄧任勛,CH0080-王金山', NULL, 'meeting', NULL, '季會', NULL, NULL, '911季會\r\n請9:00到場', '2015-09-15 09:00:00', '2015-09-15 15:22:26', '2015-09-15 15:22:26'),
	(5, 7, '0', 20, '1,20,21,25,26,121,124,166', 'admin-系統管理者,ch0004-陳怡珍,ch0083-黃勇乾,ch0071-黃玉慧,ch0082-曹宇賢,CH0063-吳凡,CH0076-邱鴻程,CH0093-游惠雯', NULL, 'meeting', NULL, '測試大會', NULL, NULL, 'test\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n', '2015-09-18 09:00:00', '2015-09-17 16:03:35', '2015-09-17 16:03:35'),
	(6, 7, '0', 20, '1,20,21,25,26,121,124,166', 'admin-系統管理者,ch0004-陳怡珍,ch0083-黃勇乾,ch0071-黃玉慧,ch0082-曹宇賢,CH0063-吳凡,CH0076-邱鴻程,CH0093-游惠雯', NULL, 'meeting', NULL, '測試大會', NULL, NULL, '[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程\r\n[黃勇傑]拜訪行程', '2015-09-24 09:00:00', '2015-09-17 17:01:06', '2015-09-17 17:01:06'),
	(7, 7, '資訊室', 20, '21,124,166', 'ch0083-黃勇乾,CH0076-邱鴻程,CH0093-游惠雯', NULL, 'notify', NULL, '通知測試', NULL, NULL, '訊息.....\r\n訊息.....\r\n訊息.....\r\n訊息.....\r\n訊息.....訊息.....\r\n訊息.....', NULL, '2015-09-21 09:00:16', '2015-09-21 09:00:16');
/*!40000 ALTER TABLE `sys_message_assign` ENABLE KEYS */;


-- 導出  表 community.sys_module 結構
CREATE TABLE IF NOT EXISTS `sys_module` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_sn` int(10) unsigned DEFAULT NULL,
  `id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:單元模組,2:特殊模組',
  `dir` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'type=1 時才判斷,是否為目錄,0:否(單元模組) 1:是',
  `level` tinyint(1) unsigned DEFAULT '1' COMMENT '單元層級(type=1 時才判斷)',
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `icon_text` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort` smallint(5) unsigned NOT NULL DEFAULT '500',
  `launch` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在導出表  community.sys_module 的資料：~32 rows (大約)
/*!40000 ALTER TABLE `sys_module` DISABLE KEYS */;
INSERT INTO `sys_module` (`sn`, `parent_sn`, `id`, `type`, `dir`, `level`, `title`, `icon_text`, `sort`, `launch`) VALUES
	(22, NULL, 'auth-dir', 1, 1, 1, '權限管理', 'fa fa-group ', 1, 1),
	(26, NULL, 'media', 1, 0, 1, '媒體庫', 'fa fa-cloud ', 3, 1),
	(30, NULL, 'setting', 1, 0, 1, '網站設定', 'fa fa-wrench', 2, 0),
	(31, NULL, 'homesetting', 1, 1, 1, '首頁設定', 'fa fa-home', 5, 0),
	(32, 22, 'auth', 1, 0, 2, '住戶資料管理', 'fa fa-comment', 5, 1),
	(33, 22, 'authgroup', 1, 0, 2, '群組管理', 'fa fa-briefcase', 6, 1),
	(36, NULL, 'log', 1, 0, 1, '系統記錄', 'fa fa-briefcase', 7, 0),
	(37, NULL, 'bulletin', 1, 0, 1, '委員公告', 'fa fa-comment-o', 5, 1),
	(39, NULL, 'repair-dir', 1, 1, 1, '社區環境修繕', 'icon-bullhorn', 10, 0),
	(40, NULL, 'suggestion', 1, 0, 1, '社區意見箱', 'fa fa-file-text-o', 11, 1),
	(41, NULL, 'data-dir', 1, 1, 1, '社區資料管理', 'icon-coffee', 12, 0),
	(46, NULL, 'news', 1, 0, 1, '社區公告', 'fa fa-newspaper-o', 4, 1),
	(47, NULL, 'app_open', 1, 0, 1, 'app開通', 'fa fa-comments-o', 10, 1),
	(48, NULL, 'vote', 1, 0, 1, '社區議題投票', 'icon-food', 1, 1),
	(49, NULL, 'mail_reg', 1, 0, 1, '郵件物品登錄', 'icon-food', 2, 1),
	(51, NULL, 'realty-dir', 1, 1, 1, '社區租售管理', 'fa fa-book', 10, 1),
	(52, 51, 'realtycat', 1, 0, 2, '分類', 'icon-food', 1, 1),
	(53, 51, 'realty', 1, 0, 2, '列表', 'icon-food', 2, 1),
	(54, NULL, 'photo-dir', 1, 1, 1, '社區活動相片', 'fa fa-file-text-o', 11, 1),
	(55, 54, 'album', 1, 0, 2, '相簿', 'icon-food', 10, 1),
	(56, 54, 'photo', 1, 0, 2, '相片', 'icon-food', 20, 1),
	(57, NULL, 'course', 1, 0, 1, '課程專區', 'fa fa-university ', 7, 1),
	(58, NULL, 'ad', 1, 1, 1, '廣告託撥', 'fa fa-newspaper-o', 12, 1),
	(59, NULL, 'ch_keycode', 1, 1, 1, '磁卡變更', 'fa fa-retweet ', 11, 1),
	(60, 59, 'gas_report', 1, 0, 1, '瓦斯報表', 'icon-coffee', 13, 1),
	(66, NULL, 'msgcenter-dir', 1, 1, 1, '住戶訊息發布', NULL, 500, 1),
	(67, 42, 'tv_file', 1, 0, 1, '電視輪播', 'icon-food', 1, 1),
	(68, NULL, 'daily_good', 1, 0, 1, '日行一善', 'fa fa-thumbs-o-up ', 6, 1),
	(70, 54, 'app_marquee', 1, 0, 2, 'app端首頁橫條資訊', 'icon-food', 999, 1),
	(71, NULL, 'keywords', 1, 1, 1, '片語管理', 'fa fa-newspaper-o', 10, 1),
	(72, 66, 'uni_msg', 1, 0, 2, '罐頭訊息', NULL, 500, 1),
	(73, 66, 'msgcenter', 1, 0, 2, '住戶訊息發布', NULL, 500, 1);
/*!40000 ALTER TABLE `sys_module` ENABLE KEYS */;


-- 導出  表 community.sys_setting 結構
CREATE TABLE IF NOT EXISTS `sys_setting` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `meta_keyword` text COLLATE utf8_unicode_ci,
  `meta_description` text COLLATE utf8_unicode_ci,
  `website_title` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `update_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在導出表  community.sys_setting 的資料：~1 rows (大約)
/*!40000 ALTER TABLE `sys_setting` DISABLE KEYS */;
INSERT INTO `sys_setting` (`sn`, `meta_keyword`, `meta_description`, `website_title`, `update_date`) VALUES
	(1, '經典,武俠遊戲,免費,輕功,十大門派,多人副本,師徒,劍3,純陽,七秀,少林,天策,萬花,藏劍,五毒,唐門,明教,丐幫,陽寶哥,珠兒,誅兒,網銀國際,moLo遊戲庫,星城,爭龍傳,尋龍,PK,陣營,惡人谷,浩氣盟,武俠電影世界,月費, MMORPG,京群,金山', '劍俠情緣叁免費版,月費改免費的武俠遊戲,最多人玩的MMORPG武俠遊戲,最有趣的捏臉系統可任意調整臉部輪廓,武林中不可或缺的同時擁有獨立的入門劇情和多樣任務,融入載具模式和物理破壞玩法的全新陣營據點爭奪玩法,提供劍俠情緣叁武俠遊戲遊戲介紹.新手指南.遊戲攻略及相關檔案下載,滿足喜愛武俠遊戲及角色扮演的線上遊戲玩家,擁有多達十大武俠門派.多樣服裝造型.紫裝.稀有虛寶任您挑', '免費版情俠情緣3', '2014-10-17 12:25:14');
/*!40000 ALTER TABLE `sys_setting` ENABLE KEYS */;


-- 導出  表 community.sys_user 結構
CREATE TABLE IF NOT EXISTS `sys_user` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用戶序號',
  `comm_id` char(8) DEFAULT NULL COMMENT '社區序號',
  `role` char(1) DEFAULT NULL COMMENT 'I:住戶    S:秘書  M:總幹事  G:警衛   F:富網通',
  `id` varchar(10) NOT NULL COMMENT '磁扣卡10碼    住戶識別號_２',
  `app_id` varchar(10) NOT NULL COMMENT '手機識別碼    住戶識別號_３',
  `building_id` varchar(6) NOT NULL COMMENT '棟別 或 門牌號(A-Z) 或 (9999)  樓層(99)    住戶識別號_１_１',
  `home_id` char(2) NOT NULL COMMENT '住戶人數編號 (99)    住戶識別號_１_２',
  `account` varchar(10) NOT NULL COMMENT '帳號（物業人員登入）',
  `password` varchar(100) NOT NULL COMMENT '密碼（物業人員登入）',
  `name` varchar(20) DEFAULT NULL COMMENT '用戶姓名',
  `email` varchar(100) DEFAULT NULL COMMENT '電子郵件',
  `level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '職等(先假設一下有職等之分)',
  `job_title` varchar(20) DEFAULT NULL,
  `gender` tinyint(1) DEFAULT '1' COMMENT '１:男　２:女',
  `phone` varchar(16) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `forever` tinyint(1) NOT NULL DEFAULT '1',
  `launch` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0:未啟用,1:啟用,2:離職',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `update_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  `last_login_ip` varchar(30) DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_login_agent` varchar(100) DEFAULT NULL,
  `is_chang_pwd` tinyint(1) DEFAULT '0',
  `u_kind` varchar(10) DEFAULT 'USER',
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='用戶資料表\r\n\r\n身分別：Ｉ-住戶　 Ｓ-物業秘書　Ｍ-物業總幹事　Ｇ-物業警衛　Ｆ-富網通\r\n\r\nＩ以 id（刷卡10碼）登錄\r\nＳＭＧ以帳密登錄';

-- 正在導出表  community.sys_user 的資料：~5 rows (大約)
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` (`sn`, `comm_id`, `role`, `id`, `app_id`, `building_id`, `home_id`, `account`, `password`, `name`, `email`, `level`, `job_title`, `gender`, `phone`, `start_date`, `end_date`, `forever`, `launch`, `is_default`, `update_date`, `create_date`, `last_login_ip`, `last_login_time`, `last_login_agent`, `is_chang_pwd`, `u_kind`) VALUES
	(1, '7', 'F', 'admin', '', '', '', 'admin', 'c4983d36fb195428c9e8c79dfa9bcb0eb20f74e0', '系統管理者', 'claire.huang@chupei.com.tw', 0, '', NULL, '', '2015-03-11 00:00:00', '2015-03-11 00:00:00', 1, 1, 1, '2016-03-29 13:52:06', '2015-03-11 16:50:23', '192.168.1.111', '2015-09-11 09:29:23', '[OS] Unknown Windows OS\n[Agent] Chrome 45.0.2454.85', 1, '0'),
	(20, '7', 'I', 'dora', '', '', '', 'dora', '524a79ae17902c7aa8f04cb54ad7978327b9b8e4', '陳怡珍', 'dora.chen@chupei.com.tw', 1, '', 2, '0928886052', '2015-07-25 11:52:18', NULL, 1, 1, 1, '2015-12-21 14:47:10', '2015-05-27 12:01:11', '192.168.1.68', '2016-03-24 14:06:27', '[OS] Unknown Windows OS\n[Agent] Chrome 49.0.2623.87', 1, 'ADMIN   '),
	(21, '7', 'I', 'vincent', '', '', '', 'vincent', '28629853f782a8a79e75b6aa70c2cdee56a74353', '黃勇乾', 'vincent.huang@chupei.com.tw', 0, '專員', 1, '0913300016', '2015-07-25 11:52:18', '2015-07-06 00:00:00', 1, 1, 1, '2015-12-21 14:47:10', '2015-06-04 13:28:01', '::1', '2016-03-24 17:23:52', '[OS] Unknown Windows OS\n[Agent] Chrome 48.0.2564.116', 1, 'ADMIN   '),
	(25, '7', 'I', 'claire', '', '', '', 'claire', '343121c90dd1f4aefc968597852f66dc50b4accc', '黃玉慧', 'claire.huang@chupei.com.tw', 1, '組長', 2, '0928051327', '2015-07-25 11:52:18', NULL, 1, 1, 1, '2015-12-21 14:47:10', '2015-06-04 13:57:20', '192.168.1.67', '2016-03-24 10:44:41', '[OS] Unknown Windows OS\n[Agent] Chrome 49.0.2623.87', 1, 'ADMIN   '),
	(26, '7', 'I', 'rick', '', '', '', 'rick', 'd6851c6a44bdb2463e10d6faf5d40d384333ff31', '曹宇賢', 'rick.tsao@chupei.com.tw', 0, '專員', 1, '0928101128', '2015-07-25 00:00:00', NULL, 1, 1, 1, '2015-12-21 14:47:10', '2015-06-04 13:58:07', '::1', '2016-03-24 17:03:29', '[OS] Unknown Windows OS\n[Agent] Firefox 45.0', 1, 'ADMIN   ');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;


-- 導出  表 community.sys_user_belong_group 結構
CREATE TABLE IF NOT EXISTS `sys_user_belong_group` (
  `sys_user_sn` int(10) unsigned NOT NULL,
  `sys_user_group_sn` int(10) unsigned NOT NULL DEFAULT '0',
  `launch` tinyint(1) DEFAULT '0',
  `update_date` datetime DEFAULT NULL,
  KEY `FK_sys_admin_belong_group_1` (`sys_user_sn`),
  KEY `FK_sys_admin_belong_group_2` (`sys_user_group_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_user_belong_group 的資料：~6 rows (大約)
/*!40000 ALTER TABLE `sys_user_belong_group` DISABLE KEYS */;
INSERT INTO `sys_user_belong_group` (`sys_user_sn`, `sys_user_group_sn`, `launch`, `update_date`) VALUES
	(26, 3, 1, NULL),
	(25, 3, 1, NULL),
	(21, 3, 1, '2016-03-28 20:44:09'),
	(25, 5, 1, '2016-03-28 21:00:30'),
	(26, 5, 1, '2016-03-28 21:00:30'),
	(1, 2, 1, '2016-03-29 13:56:16');
/*!40000 ALTER TABLE `sys_user_belong_group` ENABLE KEYS */;


-- 導出  表 community.sys_user_file_auth 結構
CREATE TABLE IF NOT EXISTS `sys_user_file_auth` (
  `sn` bigint(20) NOT NULL AUTO_INCREMENT,
  `sys_user_group_sn` int(11) DEFAULT NULL,
  `file_sn` int(11) DEFAULT NULL,
  `launch` tinyint(1) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_user_file_auth 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `sys_user_file_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_file_auth` ENABLE KEYS */;


-- 導出  表 community.sys_user_func_auth 結構
CREATE TABLE IF NOT EXISTS `sys_user_func_auth` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `sys_user_group_sn` int(11) DEFAULT NULL,
  `sys_function_sn` int(11) DEFAULT NULL,
  `is_frontend` tinyint(1) DEFAULT '1',
  `launch` tinyint(1) DEFAULT '1',
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='前端特殊權限';

-- 正在導出表  community.sys_user_func_auth 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `sys_user_func_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_func_auth` ENABLE KEYS */;


-- 導出  表 community.sys_user_group 結構
CREATE TABLE IF NOT EXISTS `sys_user_group` (
  `sn` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `launch` tinyint(1) DEFAULT '1',
  `id` varchar(10) DEFAULT NULL,
  `sort` smallint(5) unsigned NOT NULL DEFAULT '500',
  `update_date` datetime DEFAULT NULL,
  `creare_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_user_group 的資料：~5 rows (大約)
/*!40000 ALTER TABLE `sys_user_group` DISABLE KEYS */;
INSERT INTO `sys_user_group` (`sn`, `title`, `launch`, `id`, `sort`, `update_date`, `creare_date`) VALUES
	(1, '住戶', 1, 'user', 500, '2015-03-18 16:17:58', NULL),
	(2, '管委會', 1, 'advuser', 500, '2015-03-17 17:08:04', NULL),
	(3, '總幹事', 1, 'secretary', 500, '2015-03-18 10:35:16', NULL),
	(4, '警衛', 1, 'guard', 501, '2015-08-31 09:49:02', NULL),
	(5, '富網通', 1, 'fu', 501, '2015-08-05 11:42:02', NULL);
/*!40000 ALTER TABLE `sys_user_group` ENABLE KEYS */;


-- 導出  表 community.sys_user_group_b_auth 結構
CREATE TABLE IF NOT EXISTS `sys_user_group_b_auth` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sys_user_group_sn` int(10) unsigned NOT NULL DEFAULT '0',
  `module_sn` int(10) unsigned NOT NULL DEFAULT '0',
  `launch` tinyint(1) DEFAULT '0',
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`),
  KEY `FK_sys_admin_group_authority_1` (`sys_user_group_sn`),
  KEY `FK_sys_admin_group_authority_2` (`module_sn`),
  CONSTRAINT `FK_sys_admin_group_authority_sys_admin_group` FOREIGN KEY (`sys_user_group_sn`) REFERENCES `sys_user_group` (`sn`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_sys_admin_group_authority_sys_module` FOREIGN KEY (`module_sn`) REFERENCES `sys_module` (`sn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- 正在導出表  community.sys_user_group_b_auth 的資料：~51 rows (大約)
/*!40000 ALTER TABLE `sys_user_group_b_auth` DISABLE KEYS */;
INSERT INTO `sys_user_group_b_auth` (`sn`, `sys_user_group_sn`, `module_sn`, `launch`, `update_date`) VALUES
	(1, 3, 22, 1, '2016-03-31 18:44:54'),
	(4, 3, 32, 1, '2016-03-31 18:44:53'),
	(5, 3, 33, 1, '2016-03-31 18:44:53'),
	(6, 3, 48, 0, '2016-03-31 18:44:53'),
	(7, 3, 67, 0, '2016-03-31 18:44:53'),
	(8, 3, 49, 0, '2016-03-31 18:44:53'),
	(9, 3, 68, 1, '2016-03-31 18:44:53'),
	(10, 3, 26, 1, '2016-03-31 18:44:53'),
	(14, 3, 46, 1, '2016-03-31 18:44:53'),
	(15, 3, 47, 0, '2016-03-31 18:44:53'),
	(16, 3, 52, 0, '2016-03-31 18:44:53'),
	(17, 3, 53, 0, '2016-03-31 18:44:54'),
	(18, 3, 71, 0, '2016-03-31 18:44:54'),
	(19, 3, 40, 0, '2016-03-31 18:44:54'),
	(20, 3, 55, 0, '2016-03-31 18:44:54'),
	(21, 3, 56, 0, '2016-03-31 18:44:54'),
	(22, 3, 70, 0, '2016-03-31 18:44:54'),
	(23, 3, 59, 0, '2016-03-31 18:44:54'),
	(24, 3, 58, 0, '2016-03-31 18:44:54'),
	(25, 3, 60, 0, '2016-03-31 18:44:54'),
	(26, 3, 66, 1, '2016-03-31 18:44:54'),
	(27, 3, 37, 1, '2016-03-31 18:44:53'),
	(29, 3, 51, 0, '2016-03-31 18:44:54'),
	(30, 3, 54, 0, '2016-03-31 18:44:54'),
	(31, 2, 32, 0, '2016-03-29 13:56:24'),
	(32, 2, 33, 0, '2016-03-29 13:56:25'),
	(33, 2, 46, 1, '2016-03-29 13:56:25'),
	(34, 2, 48, 0, '2016-03-29 13:56:25'),
	(35, 2, 67, 0, '2016-03-29 13:56:25'),
	(36, 2, 49, 0, '2016-03-29 13:56:25'),
	(37, 2, 68, 0, '2016-03-29 13:56:25'),
	(38, 2, 26, 0, '2016-03-29 13:56:25'),
	(41, 2, 47, 0, '2016-03-29 13:56:25'),
	(42, 2, 52, 0, '2016-03-29 13:56:25'),
	(43, 2, 53, 0, '2016-03-29 13:56:25'),
	(44, 2, 71, 0, '2016-03-29 13:56:25'),
	(45, 2, 40, 0, '2016-03-29 13:56:25'),
	(46, 2, 55, 0, '2016-03-29 13:56:26'),
	(47, 2, 56, 0, '2016-03-29 13:56:26'),
	(48, 2, 70, 0, '2016-03-29 13:56:26'),
	(49, 2, 59, 0, '2016-03-29 13:56:26'),
	(50, 2, 58, 0, '2016-03-29 13:56:26'),
	(51, 2, 60, 0, '2016-03-29 13:56:26'),
	(52, 2, 66, 0, '2016-03-29 13:56:26'),
	(53, 2, 22, 0, '2016-03-29 13:56:26'),
	(54, 2, 37, 0, '2016-03-29 13:56:26'),
	(55, 2, 51, 0, '2016-03-29 13:56:26'),
	(56, 2, 54, 0, '2016-03-29 13:56:26'),
	(57, 3, 57, 1, '2016-03-31 18:44:53'),
	(58, 3, 72, 1, '2016-03-31 18:44:54'),
	(59, 3, 73, 1, '2016-03-31 18:44:54');
/*!40000 ALTER TABLE `sys_user_group_b_auth` ENABLE KEYS */;


-- 導出  表 community.sys_user_group_f_auth 結構
CREATE TABLE IF NOT EXISTS `sys_user_group_f_auth` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sys_user_group_sn` int(10) unsigned NOT NULL DEFAULT '0',
  `web_menu_sn` int(10) unsigned NOT NULL DEFAULT '0',
  `launch` tinyint(1) DEFAULT '0',
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`sn`),
  KEY `FK_sys_user_group_f_auth_sys_user_group` (`sys_user_group_sn`),
  KEY `FK_sys_user_group_f_auth_web_menu` (`web_menu_sn`),
  CONSTRAINT `FK_sys_user_group_f_auth_sys_user_group` FOREIGN KEY (`sys_user_group_sn`) REFERENCES `sys_user_group` (`sn`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_sys_user_group_f_auth_web_menu` FOREIGN KEY (`web_menu_sn`) REFERENCES `web_menu` (`sn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='群組對應前端權限關係表';

-- 正在導出表  community.sys_user_group_f_auth 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `sys_user_group_f_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_group_f_auth` ENABLE KEYS */;


-- 導出  表 community.voting 結構
CREATE TABLE IF NOT EXISTS `voting` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `allow_anony` tinyint(1) unsigned DEFAULT NULL COMMENT '0 表記名投票   1 表匿名投票 ',
  `multiple` tinyint(3) unsigned DEFAULT NULL COMMENT '0 表單選   1 表複選',
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投票主表';

-- 正在導出表  community.voting 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `voting` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting` ENABLE KEYS */;


-- 導出  表 community.voting_option 結構
CREATE TABLE IF NOT EXISTS `voting_option` (
  `sn` int(10) NOT NULL AUTO_INCREMENT,
  `voting_sn` int(10) NOT NULL,
  `text` int(10) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投票選項';

-- 正在導出表  community.voting_option 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `voting_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_option` ENABLE KEYS */;


-- 導出  表 community.voting_record 結構
CREATE TABLE IF NOT EXISTS `voting_record` (
  `voting_sn` int(10) NOT NULL,
  `option_sn` int(10) NOT NULL,
  `user_sn` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created` int(10) NOT NULL,
  PRIMARY KEY (`voting_sn`,`option_sn`,`user_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投票記錄';

-- 正在導出表  community.voting_record 的資料：~0 rows (大約)
/*!40000 ALTER TABLE `voting_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `voting_record` ENABLE KEYS */;


-- 導出  表 community.web_menu 結構
CREATE TABLE IF NOT EXISTS `web_menu` (
  `sn` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_sn` int(11) unsigned DEFAULT NULL COMMENT '父層序號',
  `level` tinyint(4) NOT NULL DEFAULT '0' COMMENT '層級',
  `title` varchar(100) NOT NULL COMMENT '名稱',
  `id` varchar(20) DEFAULT NULL COMMENT 'id',
  `img_filename` varchar(100) DEFAULT NULL COMMENT '圖片',
  `dir` tinyint(1) NOT NULL DEFAULT '0' COMMENT '目錄 (0:否,1:是)',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:網頁單元,1:連結',
  `url` varchar(255) DEFAULT NULL COMMENT 'URL(type=1時使用)',
  `target` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'target',
  `sort` smallint(6) NOT NULL DEFAULT '500' COMMENT '排序',
  `allow_internet` tinyint(1) NOT NULL DEFAULT '0',
  `launch` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:啟用,0:停用',
  `update_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`sn`),
  KEY `parent_sn` (`parent_sn`),
  CONSTRAINT `web_menu_ibfk_1` FOREIGN KEY (`parent_sn`) REFERENCES `web_menu` (`sn`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COMMENT='前端單元';

-- 正在導出表  community.web_menu 的資料：~59 rows (大約)
/*!40000 ALTER TABLE `web_menu` DISABLE KEYS */;
INSERT INTO `web_menu` (`sn`, `parent_sn`, `level`, `title`, `id`, `img_filename`, `dir`, `type`, `url`, `target`, `sort`, `allow_internet`, `launch`, `update_date`, `create_date`) VALUES
	(1, NULL, 1, '資料查詢', 'news-dir', 'img_aside_title1.png', 1, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(2, NULL, 1, '重點資訊', 'guide-dir', 'img_aside_title2.png', 1, 0, '', 0, 8, 1, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(3, NULL, 1, '行程管理', 'plan-dir', 'img_aside_title3.png', 1, 0, '', 0, 3, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(4, NULL, 1, '客戶管理', 'cust-dir', '', 1, 0, '', 0, 4, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(5, NULL, 1, '績效管理', 'download-dir', 'img_aside_title5.png', 1, 0, '', 0, 5, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(6, NULL, 1, '單位績效管理', 'service-dir', 'img_aside_title6.png', 1, 0, '', 0, 6, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(7, NULL, 1, '稽核管理', 'audit', '', 1, 0, '', 0, 7, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(8, 1, 2, '查人', 'people', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(9, 1, 2, '查土地', 'land', '', 0, 0, '', 0, 2, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(10, 1, 2, '實價登錄', 'lvr', '', 0, 0, '', 0, 4, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(11, 1, 2, '公告現值', 'landval', '', 1, 0, '', 0, 5, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(12, 1, 2, '人名查詢門牌', 'address', '', 1, 0, '', 0, 3, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(13, 2, 2, '新聞', 'news', '', 1, 0, '', 0, 2, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(14, 2, 2, '案源總表', 'cases', '', 1, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(15, 2, 2, '公告', 'bulletin', '', 1, 0, '', 0, 3, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(16, 2, 2, '常見問答', 'faq', '', 0, 0, '', 0, 4, 0, 1, '2014-10-16 14:07:31', '2014-09-23 00:00:00'),
	(17, 2, 2, '知識庫', 'km', '', 0, 0, '', 0, 5, 0, 1, '2014-10-16 14:07:45', '2014-09-23 00:00:00'),
	(18, 4, 2, '客戶總表', 'salescustomer', '', 0, 0, '', 0, 1, 0, 1, '2014-10-16 14:07:54', '2014-09-23 00:00:00'),
	(19, 4, 2, '公司分派名單', 'assigned', '', 0, 0, '', 0, 2, 0, 1, '2014-10-16 14:08:04', '2014-09-23 00:00:00'),
	(20, 64, 2, '行程回報', 'salesvisit', '', 0, 0, '', 0, 1, 0, 1, '2014-10-16 14:08:12', '2014-09-23 00:00:00'),
	(21, 4, 2, '名片客戶', 'business_card', '', 0, 0, '', 0, 5, 0, 0, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(22, 4, 2, '列管客戶名單', 'restricted', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(23, 7, 2, '全公司經營回報績效', 'performance', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(24, 3, 2, '行事曆', 'calendar', '', 0, 0, '', 0, 4, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(25, 3, 2, '行程設定', 'visit', '', 0, 0, '', 0, 5, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(27, 6, 2, '業務回報批閱', 'unit', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(28, 6, 2, '單位經營回報績效', 'unit_performance', '', 0, 0, '', 0, 2, 0, 1, '2014-10-17 14:06:26', '2014-09-23 00:00:00'),
	(29, 6, 2, '單位執行績效', 'kpi_unit', '', 0, 0, '', 0, 3, 0, 2, '2014-10-17 14:07:11', '2014-09-23 00:00:00'),
	(30, 6, 2, '單位系統使用分析', 'rules', '', 0, 0, '', 0, 4, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(31, 7, 2, '全公司執行績效分析', 'kpi_company', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(32, 7, 2, '系統使用分析', 'rookie_dir', 'img_aside_title.png', 0, 0, '', 0, 2, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(33, 7, 2, '公司分配名單分析', 'rookie', '', 0, 0, '', 0, 3, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(34, 7, 2, '異動實價分析', 'level10', '', 0, 0, '', 0, 5, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(35, 7, 2, '成交分析', 'level15', '', 0, 0, '', 0, 6, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(36, 7, 2, '公告現值分析', 'level20', '', 0, 0, '', 0, 7, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(54, NULL, 1, '圖資系統', 'map', 'img_aside_title6.png', 0, 0, '#', 0, 2, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(55, 5, 2, '執行績效', 'kpi_personal', ' ', 0, 0, ' ', 0, 2, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(56, 1, 2, '查建物', 'build', ' ', 0, 0, ' ', 0, 6, 0, 0, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(57, 2, 2, '訊息', 'msg', '', 0, 0, '', 0, 8, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(58, 2, 2, '計畫區簡介', 'plan', '', 0, 0, '', 0, 8, 0, 1, '2014-10-16 14:07:45', '2014-09-23 00:00:00'),
	(59, 64, 2, '回報歷史', 'report', '', 0, 0, '', 0, 2, 0, 1, '2014-10-16 14:08:12', '2014-09-23 00:00:00'),
	(60, 4, 2, '客戶社團', 'league', '', 0, 0, '', 0, 7, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(61, 4, 2, '客戶社區', 'community', '', 0, 0, '', 0, 8, 0, 0, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(63, 2, 2, '配地試算', 'a7', 'img_aside_title1.png', 0, 0, '', 1, 6, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(64, NULL, 1, '行程回報', 'report-dir', 'img_aside_title3.png', 1, 0, '', 0, 3, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(65, 7, 2, '列管名單分析', 'control', '', 0, 0, '', 0, 5, 0, 2, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(66, 4, 2, '自行新增名單', 'byself', '', 0, 0, '', 0, 3, 0, 1, '2014-10-16 14:08:04', '2014-09-23 00:00:00'),
	(67, 73, 2, '建商列表', 'builder', 'img_aside_title6.png', 0, 0, '#', 0, 3, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(68, 2, 2, 'A7權值查詢', 'a7_right', 'img_aside_title1.png', 0, 0, '', 0, 6, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(69, 2, 2, 'A7配地查詢', 'a7_sign', 'img_aside_title1.png', 0, 0, '', 0, 6, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(70, 2, 2, 'A7圖資查詢', 'a7_map', 'img_aside_title1.png', 0, 0, '', 1, 7, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(71, 2, 2, 'A7配地成果圖', 'a7_result', 'img_aside_title1.png', 0, 0, '', 0, 7, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(72, 73, 2, '建商列表_', 'builderlist', 'img_aside_title6.png', 0, 0, '#', 0, 1, 0, 0, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(73, NULL, 1, '建商模組', 'builder-dir', 'img_aside_title6.png', 1, 0, '#', 0, 3, 0, 1, '2014-09-23 00:00:00', '0000-00-00 00:00:00'),
	(74, 5, 2, '經營回報績效', 'personal_performance', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(76, 5, 2, '目標管理', 'kpi_target', ' ', 0, 0, ' ', 0, 5, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(77, 6, 2, '單位目標管理', 'kpi_unit_target', '', 0, 0, '', 0, 4, 0, 1, '2014-10-17 14:07:11', '2014-09-23 00:00:00'),
	(78, 7, 2, '全公司戰報', 'reward', '', 0, 0, '', 0, 1, 0, 1, '2014-09-23 00:00:00', '2014-09-23 00:00:00'),
	(79, 6, 2, '單位戰報', 'reward_unit', '', 0, 0, '', 0, 9, 0, 1, '2014-10-17 14:07:11', '2014-09-23 00:00:00');
/*!40000 ALTER TABLE `web_menu` ENABLE KEYS */;


-- 導出  表 community.web_menu_banner 結構
CREATE TABLE IF NOT EXISTS `web_menu_banner` (
  `sn` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `banner_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '檔案名稱',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `forever` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `launch` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `sort` int(10) unsigned NOT NULL DEFAULT '500',
  `url` text COLLATE utf8_unicode_ci,
  `target` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci,
  `update_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在導出表  community.web_menu_banner 的資料：~17 rows (大約)
/*!40000 ALTER TABLE `web_menu_banner` DISABLE KEYS */;
INSERT INTO `web_menu_banner` (`sn`, `title`, `banner_id`, `filename`, `start_date`, `end_date`, `forever`, `launch`, `sort`, `url`, `target`, `content`, `update_date`, `create_date`) VALUES
	(5, '關於協鈦', 'aboutus', '20140204225120_683961.jpg', '2014-05-08 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-05-08 14:24:43', '0000-00-00 00:00:00'),
	(9, 'dd', 'homepage', '20130805000623_533630.jpg', '2013-08-05 00:00:00', NULL, 1, 1, 500, '', 0, '', '2013-08-05 21:57:20', '0000-00-00 00:00:00'),
	(11, 'xsdf', 'homepage', '20130804214238_187780.jpg', '2013-08-04 00:00:00', NULL, 1, 1, 500, '', 0, '', '2013-08-04 21:42:38', '0000-00-00 00:00:00'),
	(14, '電動鎚鑽', 'index_gallery', '20140102230748_654644.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 1, '', '2014-01-02 23:26:52', '0000-00-00 00:00:00'),
	(15, '充電式起子機', 'index_gallery', '20140102230753_683126.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 1, '', '2014-01-02 23:26:57', '0000-00-00 00:00:00'),
	(16, 'WURTH-滲透潤滑劑', 'index_gallery', '20140102230800_183001.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-02 23:27:02', '0000-00-00 00:00:00'),
	(17, '', 'index_promo', '20130804233927_333926.jpg', '2013-08-05 00:00:00', NULL, 1, 1, 500, '', 0, '', '2013-08-05 22:03:24', '0000-00-00 00:00:00'),
	(18, '產品介紹', 'product', '20140204225128_962787.jpg', '2014-02-04 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-02-04 22:51:28', '0000-00-00 00:00:00'),
	(19, '線上諮詢', 'contact', '20140204225009_392852.jpg', '2014-02-04 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-02-04 22:50:09', '0000-00-00 00:00:00'),
	(20, '氣動鎚鑽', 'index_gallery', '20140102230806_397180.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-02 23:08:06', '0000-00-00 00:00:00'),
	(21, 'TH-模型專用刻線板', 'index_gallery', '20140315104228_532461.gif', '2014-03-15 00:00:00', NULL, 1, 1, 1, 'www.google.com', 1, '', '2014-03-15 10:47:48', '0000-00-00 00:00:00'),
	(22, '最新消息', 'news', '20140106233110_380700.jpg', '2014-01-06 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-06 23:31:10', '0000-00-00 00:00:00'),
	(23, '螺絲小常識', 'faq', '20140204225138_634090.jpg', '2014-02-04 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-02-04 22:51:38', '0000-00-00 00:00:00'),
	(24, 'xxx', 'index_gallery', '20140102230816_454144.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-02 23:08:16', '0000-00-00 00:00:00'),
	(25, 'ccccx', 'index_gallery', '20140102230826_511108.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-02 23:08:26', '0000-00-00 00:00:00'),
	(26, 'ggg', 'index_gallery', '20140102230836_568072.jpg', '2014-01-02 00:00:00', NULL, 1, 1, 500, '', 0, '', '2014-01-02 23:08:36', '0000-00-00 00:00:00'),
	(27, 'Test', 'index_gallery', '20140123222635_394801.jpg', '2014-01-23 00:00:00', NULL, 1, 1, 500, 'http://tw.yahoo.com', 1, '', '2014-01-23 22:26:35', '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `web_menu_banner` ENABLE KEYS */;


-- 導出  表 community.web_menu_content 結構
CREATE TABLE IF NOT EXISTS `web_menu_content` (
  `sn` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `comm_id` char(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '社區序號',
  `id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_sn` int(11) unsigned DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `brief` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `brief2` text COLLATE utf8_unicode_ci,
  `content_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `img_filename` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '圖片名稱',
  `img_filename2` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '圖片名稱2',
  `filename` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '檔案名稱',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `dir` tinyint(1) NOT NULL DEFAULT '0',
  `forever` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `launch` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `sort` int(10) unsigned NOT NULL DEFAULT '500',
  `url` text COLLATE utf8_unicode_ci,
  `target` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci,
  `hot` tinyint(1) NOT NULL DEFAULT '0',
  `update_date` datetime NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM AUTO_INCREMENT=1865 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 正在導出表  community.web_menu_content 的資料：47 rows
/*!40000 ALTER TABLE `web_menu_content` DISABLE KEYS */;
INSERT INTO `web_menu_content` (`sn`, `comm_id`, `id`, `parent_sn`, `title`, `brief`, `brief2`, `content_type`, `img_filename`, `img_filename2`, `filename`, `start_date`, `end_date`, `dir`, `forever`, `launch`, `sort`, `url`, `target`, `content`, `hot`, `update_date`, `create_date`) VALUES
	(394, '0', 'news_rule', NULL, '法規', 'news_5', '', 'newscat', 'newscat_20150627114039_918041.jpg', '', '', '2015-07-29 14:33:26', NULL, 0, 1, 1, 5, '', 0, '', 0, '2015-07-29 14:33:26', '2015-04-23 14:50:23'),
	(399, '0', NULL, NULL, '外牆格柵維修', '', '', 'news', '', '', '', '2016-03-24 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2016-03-29 14:13:16', '2015-04-23 15:10:25'),
	(400, '0', NULL, NULL, 'C棟頂樓防水工程施工', '', '', 'news', '', '', '', '2016-03-25 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2016-03-29 14:13:06', '2015-04-23 17:50:24'),
	(406, '0', 'bulletin_training', NULL, '教育訓練', '', '', 'bulletincat', '', '', '', '2015-04-27 18:50:54', NULL, 0, 1, 1, 1, '', 0, '', 0, '2015-04-27 18:50:54', '2015-04-27 18:49:26'),
	(407, '0', 'bulletin_mgr', NULL, '管理辦法', '', '', 'bulletincat', '', '', '', '2015-04-27 18:51:14', NULL, 0, 1, 1, 2, '', 0, '', 0, '2015-04-27 18:51:14', '2015-04-27 18:50:43'),
	(408, '0', 'bulletin_person', NULL, '人事公告', '', '', 'bulletincat', '', '', '', '2015-04-27 18:51:54', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-04-27 18:51:54', '2015-04-27 18:51:54'),
	(409, '0', 'bulletin_sys', NULL, '系統公告', '', '', 'bulletincat', '', '', '', '2015-04-27 18:54:05', NULL, 0, 1, 1, 4, '', 0, '', 0, '2015-04-27 18:54:05', '2015-04-27 18:54:05'),
	(422, '0', 'news_land', NULL, '土地', 'news_1', '', 'newscat', 'newscat_20150627105710_205249.jpg', '', '', '2015-07-29 14:32:56', NULL, 0, 1, 1, 1, '', 0, '', 0, '2015-07-29 14:32:56', '2015-04-28 12:04:03'),
	(423, '0', 'news_house', NULL, '房巿', 'news_2', '', 'newscat', 'newscat_20150627105723_443020.jpg', '', '', '2015-07-29 14:33:06', NULL, 0, 1, 1, 2, '', 0, '', 0, '2015-07-29 14:33:06', '2015-04-28 12:04:24'),
	(424, '0', 'news_sales', NULL, '標售', 'news_3', '', 'newscat', 'newscat_20150627114225_710702.jpg', '', '', '2015-07-29 14:33:12', NULL, 0, 1, 1, 3, '', 0, '', 0, '2015-07-29 14:33:12', '2015-04-28 12:04:56'),
	(425, '0', 'news_tax', NULL, '稅務', 'news_4', '', 'newscat', 'newscat_20150627105801_861160.jpg', '', '', '2015-07-29 14:33:20', NULL, 0, 1, 1, 4, '', 0, '', 0, '2015-07-29 14:33:20', '2015-04-28 12:05:22'),
	(427, '0', 'sys', NULL, '系統', '', '', 'faqcat', '', '', '', '2015-05-22 09:41:43', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 09:41:43', '2015-05-22 09:41:43'),
	(428, '0', 'sales', NULL, '業務', '', '', 'faqcat', '', '', '', '2015-05-22 09:52:27', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 09:52:27', '2015-05-22 09:52:27'),
	(429, '0', 'mgr', NULL, '行政', '', '', 'faqcat', '', '', '', '2015-05-22 09:54:15', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 09:54:15', '2015-05-22 09:54:15'),
	(430, '0', NULL, 429, '如何透過網路查詢閱覽地政資料？其收費標準及收費方式為何？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 09:58:36', '2015-05-22 09:58:36'),
	(431, '0', NULL, 429, '如何查詢某塊土地為私有或公有土地？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 10:02:11', '2015-05-22 10:02:11'),
	(432, '0', NULL, 429, '何謂土地、建物登記謄本？與土地、建物所有權狀有何不同？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 10:02:58', '2015-05-22 10:02:58'),
	(433, '0', NULL, 428, '僅知道房屋門牌，可否查詢地、建號及申請謄本？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 10:03:31', '2015-05-22 10:03:31'),
	(434, '0', NULL, 427, '如何申請閱覽、複印已歸檔登記申請書及其附件？應備文件？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 10:03:59', '2015-05-22 10:03:59'),
	(435, '0', NULL, 428, '地籍謄本如何申請？有哪些申請管道？可以通訊申請或傳真申請嗎？傳真號碼為何？費用如何計收？', '', '', 'faq', '', '', '', '2015-05-22 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-22 10:04:25', '2015-05-22 10:04:25'),
	(436, '0', 'km_sales', NULL, '業務養成', '', '', 'kmcat', '', '', '', '2015-05-29 09:31:58', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:31:58', '2015-05-28 17:06:05'),
	(437, '0', 'km_biz', NULL, '企管財經', '', '', 'kmcat', '', '', '', '2015-05-29 09:31:40', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:31:40', '2015-05-28 17:10:21'),
	(438, '0', 'km_market', NULL, '巿場經濟', '', '', 'kmcat', '', '', '', '2015-05-29 09:30:41', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:30:41', '2015-05-28 17:10:37'),
	(439, '0', 'km_heart', NULL, '心靈成長', '', '', 'kmcat', '', '', '', '2015-05-29 09:30:19', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:30:19', '2015-05-28 17:11:31'),
	(440, '0', 'km_training', NULL, ' 教育訓練', '', '', 'kmcat', '', '', '', '2015-05-29 09:30:08', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:30:08', '2015-05-28 17:11:53'),
	(441, '0', 'km_brief', NULL, '簡報資料', '', '', 'kmcat', '', '', '', '2015-05-29 09:29:51', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-05-29 09:29:51', '2015-05-28 17:12:23'),
	(442, '0', NULL, 441, '建地跟農地差別在哪 ?', '', '', 'km', '', '', '', '2015-05-28 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:54:01', '2015-05-28 17:16:05'),
	(443, '0', NULL, 440, '何謂建地、農地? ', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:53:39', '2015-05-29 11:53:39'),
	(444, '0', NULL, 441, '現今買農地興建農舍有何限制？', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:54:25', '2015-05-29 11:54:25'),
	(445, '0', NULL, 439, '請問農舍建敝率及容積為何？', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:54:42', '2015-05-29 11:54:42'),
	(446, '0', NULL, 438, '買農地須注意什麼？', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:54:56', '2015-05-29 11:54:56'),
	(447, '0', NULL, 441, '何謂配建農舍？', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:55:12', '2015-05-29 11:55:12'),
	(448, '0', NULL, 437, '問農地可否共同持有？將來如有共有人欲將所有持分出售，如何處理呢？', '', '', 'km', '', '', '', '2015-05-29 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-05-29 11:55:44', '2015-05-29 11:55:44'),
	(469, '0', NULL, NULL, 'test7', '', '', 'faq', '', '', '', '2015-07-06 00:00:00', NULL, 0, 1, 0, 500, '', 0, '', 0, '2015-07-06 10:23:02', '2015-07-06 10:23:02'),
	(563, '0', 'jackie', NULL, '資訊公告', '', '', 'bulletincat', '', '', '', '2015-07-16 15:36:49', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-07-16 15:36:49', '2015-07-16 15:33:16'),
	(618, '0', NULL, 409, '系統轉換-暫時停止填寫回報', '', '', 'bulletins', '', '', '', '2015-08-26 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-08-26 14:10:44', '2015-08-26 14:10:44'),
	(631, '0', NULL, 409, '新系統網站開放上線使用', '', '', 'bulletins', '', '', '', '2015-08-28 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-08-28 16:58:26', '2015-08-28 16:58:26'),
	(670, '0', NULL, 406, '敬請盡量避免使用"自行新增"填寫回報', '', '', 'bulletins', '', '', '', '2015-09-10 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-09-10 16:13:43', '2015-09-10 16:13:43'),
	(975, '0', NULL, 424, '新北市6件市有土地及房地標租', 'MY GO NEWS', '', '', '', '', '', '2015-11-20 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-11-20 08:49:53', '2015-11-20 08:49:53'),
	(976, '0', NULL, 424, '新北市6件市有土地及房地標租', 'MY GO NEWS', '', '', '', '', '', '2015-11-20 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-11-20 08:50:26', '2015-11-20 08:50:26'),
	(977, '0', NULL, 424, '新北市6件市有土地及房地標租', 'MY GO NEWS', '', '', '', '', '', '2015-11-20 00:00:00', NULL, 0, 1, 1, 500, '', 0, '', 0, '2015-11-20 08:50:59', '2015-11-20 08:50:59'),
	(1859, NULL, NULL, NULL, 'cccsss', '', '', 'news', '', '', '', '2016-03-29 00:00:00', NULL, 0, 1, 1, 500, '', 0, 'cccsss', 0, '2016-03-29 20:26:49', '2016-03-29 20:26:49'),
	(1860, '5tgb4rfv', NULL, NULL, 'aaa', '', '', 'news', '', '', '', '2016-03-29 00:00:00', NULL, 0, 1, 1, 500, '', 0, 'bsdfsdfds', 0, '2016-03-29 20:35:25', '2016-03-29 20:35:25'),
	(1861, '5tgb4rfv', NULL, NULL, 'testffff', '', '', 'bulletin', '', '', '', '2016-03-29 00:00:00', NULL, 0, 1, 1, 500, '', 0, '內容內容內容內容', 0, '2016-03-29 20:58:44', '2016-03-29 20:58:44'),
	(1862, '5tgb4rfv', NULL, NULL, 'vv', '', '', 'daily_good', '', '', '', '2016-03-29 00:00:00', NULL, 0, 1, 1, 500, '', 0, 'sdfs', 0, '2016-03-29 21:27:53', '2016-03-29 21:27:53'),
	(1863, '5tgb4rfv', NULL, NULL, 'aaa', 'bbb', '', 'daily_good', '', '', '', '2016-03-29 00:00:00', NULL, 0, 1, 1, 500, '', 0, 'cccc', 0, '2016-03-29 21:32:51', '2016-03-29 21:32:51'),
	(1864, '5tgb4rfv', NULL, NULL, 'english class 1', '1', '', 'course', '', '', '', '2016-03-30 00:00:00', NULL, 0, 0, 1, 500, '', 0, 'ddddd', 0, '2016-03-30 19:24:26', '2016-03-30 19:24:26');
/*!40000 ALTER TABLE `web_menu_content` ENABLE KEYS */;


-- 導出  表 community.web_setting 結構
CREATE TABLE IF NOT EXISTS `web_setting` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `key` varchar(100) CHARACTER SET utf8 NOT NULL,
  `value` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `memo` varchar(100) CHARACTER SET utf8 NOT NULL,
  `type` varchar(20) CHARACTER SET utf8 NOT NULL,
  `sort` smallint(3) NOT NULL DEFAULT '500',
  `launch` tinyint(1) NOT NULL DEFAULT '1',
  `update_date` datetime NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- 正在導出表  community.web_setting 的資料：~6 rows (大約)
/*!40000 ALTER TABLE `web_setting` DISABLE KEYS */;
INSERT INTO `web_setting` (`sn`, `title`, `key`, `value`, `memo`, `type`, `sort`, `launch`, `update_date`) VALUES
	(1, 'SEO Keywords', 'meta_keyword', '經典,武俠遊戲,免費,輕功,十大門派,多人副本,師徒,劍3,純陽,七秀,少林,天策,萬花,藏劍,五毒,唐門,明教,丐幫,陽寶哥,珠兒,誅兒,網銀國際,moLo遊戲庫,星城,爭龍傳,尋龍,PK,陣營,惡人谷,浩氣盟,武俠電影世界,月費, MMORPG,京群,金山', '', 'textarea', 2, 1, '2014-10-30 14:25:38'),
	(2, 'SEO Description', 'meta_description', '劍俠情緣叁免費版,月費改免費的武俠遊戲,最多人玩的MMORPG武俠遊戲,最有趣的捏臉系統可任意調整臉部輪廓,武林中不可或缺的同時擁有獨立的入門劇情和多樣任務,融入載具模式和物理破壞玩法的全新陣營據點爭奪玩法,提供劍俠情緣叁武俠遊戲遊戲介紹.新手指南.遊戲攻略及相關檔案下載,滿足喜愛武俠遊戲及角色扮演的線上遊戲玩家,擁有多達十大武俠門派.多樣服裝造型.紫裝.稀有虛寶任您挑', '', 'textarea', 3, 1, '2014-10-30 14:25:38'),
	(3, '網站名稱', 'website_title', '免費版情俠情緣3', '', 'text', 1, 1, '2014-10-30 14:25:38'),
	(4, 'Google Search ID', 'google_search_id', '017154571463157724076:p-zsbzzctk4', '', 'text', 4, 1, '2014-10-30 14:25:38'),
	(5, '搜尋關鍵字', 'google_search_keywords', '五毒,稻香村,新手', '關鍵字請以逗點(,)隔開', 'text', 5, 1, '2014-10-30 14:25:38'),
	(6, 'google analytics', 'google_analytics', '  (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\r\n  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\r\n  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\r\n  })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');\r\n\r\n     ga(\'create\', \'UA-33575663-19\', \'http://jx3.molome.tw\');\r\n   ga(\'create\', \'UA-33575663-19\', \'auto\');\r\n   ga(\'require\', \'linkid\', \'linkid.js\'); //啟用事件跟踪\r\n     ga(\'require\', \'displayfeatures\'); //啟用客層和興趣報表\r\n   ga(\'send\', \'pageview\');', '', 'textarea', 5, 1, '2014-10-30 14:25:38');
/*!40000 ALTER TABLE `web_setting` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
